<?php

$schema['departments.update'] = array (
    array (
        'title' => 'departments',
        'link' => 'departments.manage'
    )
);

return $schema;
