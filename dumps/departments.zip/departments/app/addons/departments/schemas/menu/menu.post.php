<?php

$schema['central']['customers']['items']['departments'] = [
    'attrs' => [
        'class' => 'is-addon'
    ],
    'href' => 'departments.manage',
    'alt' => 'departments.manage',
    'position' => 1100,
];

return $schema;