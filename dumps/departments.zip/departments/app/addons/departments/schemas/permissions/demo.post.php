<?php

$schema['departments'] = array (
    'restrict' => array ('POST')
);

return $schema;
